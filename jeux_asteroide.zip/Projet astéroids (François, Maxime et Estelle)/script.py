#projet 1 T NSI LVC 2021-2022


#imports
import os
import sys
import random
import time
import math
import turtle
if sys.platform == "win32":
    import winsound

#CONSTANTES
RAYON = 400
TROU_NOIR = (500,500)

turtle.setup(width=810, height=810)
turtle.speed(0)
turtle.bgcolor("#031c45")#"midnightblue")
turtle.title("Asteroids")
turtle.ht()
turtle.setundobuffer(1)
turtle.tracer(0)

class Animation(turtle.Turtle):
    """
    classe fille de Turtle donc  hérite des attributs position
    direction et
    méthodes de la classe Turtle
    définit  une forme
    -triangle(vaisseau) rayon 11.5
    -cercle (missile) rayon 2.5
    -asteroide rayon 40,20,10

    Une animation est définie par son centre (x,y), son rayon, sa vitesse
    screen.register_shape()
    """
    def __init__(self, forme, couleur,x0,y0,vitesse,rayon,couleur_fond="black"):
        """
        RAYON = 400 px rayon de l'univers
        """
        turtle.Turtle.__init__(self, shape = forme)
        self.speed(0)
        self.color(couleur,couleur_fond)
        self.fd(0)
        #apparaît en (x0,y0)
        self.penup()
        self.goto(x0, y0)
        #le rayon du cercle circonscrit de l'animation
        self.rayon = rayon
        self.vitesse = vitesse

    def avancer(self):
        #l'univers est un tore
        if self.xcor() > RAYON - self.rayon:
            self.setx(-RAYON + self.rayon)
        elif self.xcor() < -RAYON + self.rayon:
            self.setx(RAYON - self.rayon)
        if self.ycor() >  RAYON - self.rayon:
            self.sety(-RAYON + self.rayon)
        elif self.ycor() < -RAYON + self.rayon:
            self.sety(RAYON - self.rayon)

        self.fd(self.vitesse)

    def toucher(self,other):
        return  self.distance(other.pos()) <= self.rayon +\
         other.rayon

class Vaisseau(Animation):
    """
    Vaisseau hérite de Animation qui hérite de Turtle donc Vaisseau a les attributs
    de Turtle , position ,direction etc...
    """
    #attributs de classe
    rayon = 11.5
    angle = 20
    limite_safe = 100
    nb_tir = 0


    def __init__(self):

        Animation.__init__(self,
                           "triangle",
                           '#2febd2',#'white',
                           0,
                           0,
                           0,
                           Vaisseau.rayon)
        self.shapesize(0.9, 1,outline=None)
        self.vitesse = 0
        self.tirs = []
        self.nb_vies = 3
        self.niveau = 1
        self.score = 0
        self.soin = []

    def tourner_a_droite(self):
        self.right(Vaisseau.angle)

    def tourner_a_gauche(self):
        self.left(Vaisseau.angle)

    def accelerer(self):
        self.vitesse += 1

    def ralentir(self):
        if self.vitesse < 1:
            self.vitesse = 0
        elif self.vitesse > 0:
            self.vitesse -= 1

    def kill(self):
        self.nb_vies = 0

    def devier(self,direction,vitesse_a):
        """
        Si un astéroide touche le vaisseau
        ce dernier est dévié de sa trajectoire
        en prenant la direction de l'asteroide
        """
        if self.vitesse == 0:
            self.setheading(direction)
            self.vitesse = vitesse_a
            self.fd(20)
        else:
            self.setheading(self.heading()-180)
            self.fd(20)


    def tirer(self):
        nom_os = sys.platform
        if nom_os == 'Darwin':
            os.system("afplay tir.wav&")

        elif nom_os == 'Linux':
            os.system("aplay tir.wav &")

        elif nom_os == 'win32':
            winsound.PlaySound("tir.wav", winsound.SND_ASYNC)

        self.tirs.append(Missile(self.xcor(),self.ycor(),
                         self.heading(),
                         self.vitesse+ 5))
        self.nb_tir += 1


class Asteroide(Animation):
    valeur_asteroide = [20,50,100]

    def __init__(self,taille, x0, y0,vitesse):

        """
        taille = 1 gros astéroide
        taille = 0.5 moyen
        taille = 0.25 petit
        """
        Animation.__init__(self,
                           'asteroide',
                           '#ff0000',#'saddlebrown',
                           x0,
                           y0,
                           vitesse,
                           taille*40,
                           "black")
        self.shapesize(stretch_wid=taille, stretch_len=taille,
        outline=None)
        self.vitesse = vitesse
        self.taille = taille
        self.setheading(random.randint(0,360))
        self.rayon = taille*40

    def exploser(self,asteroides,vaisseau):
        if self.taille == 1:
            vaisseau.score += self.valeur_asteroide[0]
        elif self.taille == 0.5:
            vaisseau.score += self.valeur_asteroide[1]
        elif self.taille == 0.25:
            vaisseau.score += self.valeur_asteroide[2]

        if self.taille != 0.25:
            self.taille /=2
            self.rayon //=2
            #réduction de moitié
            self.shapesize(self.taille, self.taille,outline=None)
            #augmentation de la vitesse
            self.vitesse += 0.5
            #apparition d'un autre astéroïde de même taille
            #et de même vitesse
            asteroides.append(Asteroide(self.taille,
                                        self.xcor()+self.rayon,
                                        self.ycor(),
                                        self.vitesse))
        else:
            vaisseau.score += 100
            self.goto(TROU_NOIR)
            asteroides.remove(self)

class Missile(Animation):
    """
    Missiles tiré par le joueur et qui ne touche que les astéroides
    """
    rayon = 4.5

    def __init__(self,x0, y0,direction,vitesse):

        Animation.__init__(self,
                           "circle",
                           "yellow",
                           x0,
                           y0,
                           vitesse,
                           Missile.rayon)
        self.shapesize(0.15, 0.25,outline=None)
        self.setheading(direction)



    def avancer(self):
        """
        On surcharge la méthode car une missile
        qui sort de l'univers (l'écran) va dans un trou noir
        """

        if abs(self.xcor()) > RAYON or abs(self.ycor()) > RAYON:
            self.vitesse = 0
            self.goto(TROU_NOIR)

        else:
            self.fd(self.vitesse)

class Missile_Soucoupe(Animation):
    """
    Missiles tiré par la soucoupe et qui ne touche que le joueur.
    """
    rayon = 10

    def __init__(self,x0, y0,direction,vitesse):

        Animation.__init__(self,
                           "circle",
                           "#dd0000",
                           x0,
                           y0,
                           vitesse,
                           Missile.rayon)
        self.shapesize(0.25, 0.35,outline=None)
        self.setheading(direction)



    def avancer2(self):
        """
        On surcharge la méthode car une missile
        qui sort de l'univers (l'écran) va dans un trou noir
        """

        if abs(self.xcor()) > RAYON or abs(self.ycor()) > RAYON:
            self.vitesse = 0
            self.goto(TROU_NOIR)

        else:
            self.fd(self.vitesse)

class Soin(Animation):
    TAILLE_SOIN = 10
    def __init__(self,x0,y0):
        Animation.__init__(self,
                           "circle",
                           "green",
                           x0,
                           y0,
                           0,
                           Soin.TAILLE_SOIN,
                           "green")
        self.shapesize(0.75,0.75)#,outline=0)

class Soucoupe(Animation):
    taille = 3
    vitesse = 0
    debut = time.time()
    dernier_tir = debut
    tir_missile = []

    def __init__(self, x0, y0):

        """
        La même fonction que pour l'asteroide mais avec des points differents et
        une seule taille.
        """
        Animation.__init__(self,
                           'soucoupe',
                           '#ff0000',#'saddlebrown',
                           x0,
                           y0,
                           Soucoupe.vitesse,
                           Soucoupe.taille)
        self.shapesize(stretch_wid=Soucoupe.taille,
                       stretch_len=Soucoupe.taille,
                       outline=None)
        self.vitesse = Soucoupe.vitesse
        self.taille = Soucoupe.taille
        self.rayon = Soucoupe.taille

    def partir(self):
        self.goto(TROU_NOIR)
        for missile_S in self.tir_missile:
            self.tir_missile.remove(missile_S)

    def tirer(self,x,y):
        """
        Paramétre:
        ----------
            x:int
                position en x du vaisseau
            y:int
                position en y du vaisseau
        il ne faut pas bloquer les autre processus tout en faisant que le vaisseau ne cannarde pas le joueur.
        En mettant un delai.
        """
        if time.time() - self.dernier_tir >= 1:
            self.tir_missile.append(Missile_Soucoupe(self.xcor(),
                                                     self.ycor(),
                                                     self.viser(x-1,y-1),#Vaisseau.xcor(),Vaisseau.ycor()),
                                                     10))
            self.dernier_tir = time.time()



    def viser(self,v_x,v_y):
        """
        retourne l'angle pour viser le vaisseau
        on a deux vecteur qui sont definit dans les deux remiére par des listes
        puis on retourne la formule qu'on met en degrés.
        l'arcosinus du rapport du produit scalaire des vecteurs sur le produit des normes = soit arcos(u.v / ||u|| * ||v||)
        """
        vec_vise = [v_x - self.xcor(), v_y - self.ycor()]
        vec_horizon = [-1, 1]
        angle = -math.degrees(math.acos((v_x-self.xcor())/math.sqrt(((v_x-self.xcor())**2) + (v_y-self.ycor())**2)))
        return angle

class Jeu:

    nb_touche = 0
    debut_game = time.time()
    temps_avant_apparition_soucoupe = [(i*3)*60 for i in range(1,4)]
    temps_avant_apparition_soucoupe.insert(0,60)
    temps_avant_apparition_soucoupe.append(1000000)
    nb_apparition = 0
    soucoupe_la = False

    def __init__(self):

        #le terrain de jeu
        self.ecran = turtle.Screen()
        #on définit la forme asteroide
        asteroide =((-34.6,20),
                    (-34.6,-20),
                    (0,-40),
                    (34.6,-20),
                    (34.6,20),
                    (20,20),
                    (0,40))

        soucoupe = ((-0,70),
                    (20,30),
                    (20,-30),
                    (-0,-70),
                    (-10,-20),
                    (-30,-0),
                    (-10,20))
        #on l'enregistre
        self.ecran.register_shape('asteroide', asteroide)
        self.ecran.register_shape('soucoupe',soucoupe)
        #définir et enregistrer la soucoupe volante

        #le marqueur du score
        self.stylo = turtle.Turtle()
        self.stylo.ht()
        self.stylo.speed(0)
        self.stylo.color("white")
        self.stylo.pensize(3)

        #commencer une partie
        self.commencer_une_partie = False
        #écouteur
        turtle.onkeypress(self.commencer, "Up")
        turtle.listen()
        #ouvrir le fichier texte des scores en lecture
##        with open("scores.txt",'r',encoding='utf-8') as fichier:
##            self.liste_scores = fichier.read().splitlines()

    def commencer(self):
        self.commencer_une_partie = True
        self.vaisseau = Vaisseau()
        #un attribut  asteroides de type list

        self.asteroides = [Asteroide(1,
                                     self.pos_x_possible()[random.randint(0,self.vaisseau.niveau +2)],
                                     self.pos_y_possible()[random.randint(0,self.vaisseau.niveau +2)],
                                     0.2) for i in range(self.vaisseau.niveau + 2)]

        #un attribut de type Vaisseau

        #des écouteurs d'évènements
        turtle.onkeypress(self.vaisseau .tourner_a_gauche, "Left")
        turtle.onkeypress(self.vaisseau .tourner_a_droite, "Right")
        turtle.onkeypress(self.vaisseau .accelerer, "Up")
        turtle.onkeypress(self.vaisseau .ralentir, "Down")

        turtle.onkeypress(self.vaisseau.tirer, "space")
        turtle.onkeypress(self.soucoupe_test, "a")

        turtle.onkeypress(self.vaisseau .kill, "k")

        turtle.listen()

    def pos_x_possible(self):
        """
        Verifie qu'une coordonnée x (génèré aléatoirement par la fonction) est est dans la zone de sureté du vaisseau
        si c'est le cas la fonction regénère aleatoirement une autre valeur et la retest
        quand la valeur génèré n'est pas dans la zone de sureté alors la fonction la stock dans une liste qu'elle retourne quand un certain nombre de valeur ont été testé
        """
        x = []
        for i in range(10):
            px = random.randint(-300,300)
            while self.vaisseau.xcor() + self.vaisseau.limite_safe > px and self.vaisseau.xcor() - self.vaisseau.limite_safe < px:
                px = random.randint(-300,300)
            x.append(px)
        return x

    def pos_y_possible(self):
        """
        Verifie qu'une coordonnée y (génèré aléatoirement par la fonction) est est dans la zone de sureté du vaisseau
        si c'est le cas la fonction regénère aleatoirement une autre valeur et la retest
        quand la valeur génèré n'est pas dans la zone de sureté alors la fonction la stock dans une liste qu'elle retourne quand un certain nombre de valeur ont été testé
        """
        y = []
        for i in range(10):
            py = random.randint(-300,300)
            while self.vaisseau.ycor() + self.vaisseau.limite_safe > py and self.vaisseau.ycor() - self.vaisseau.limite_safe < py:
                py = random.randint(-300,300)
            y.append(py)
        return y

    def soucoupe_test(self):
        self.S = Soucoupe(1,200)
        #S.scenario(self.vaisseau.xcor(),self.vaisseau.ycor())

##    def verifier_pos(self,x,y):
##        return math.sqrt(((self.vaisseau.xcor + x)**2)-((self.vaisseau.ycor + y)**2)) > self.vaisseau.limite_safe

    def passer_au_niveau_superieur(self,niveau):
        self.asteroides = [Asteroide(1,
                                     self.pos_x_possible()[random.randint(0,self.vaisseau.niveau +2)],
                                     self.pos_y_possible()[random.randint(0,self.vaisseau.niveau +2)],
                                     0.2) for i in range(niveau + 3)]

    def partie_est_en_cours(self):
        return self.vaisseau.nb_vies != 0

    def jouer(self):
        #changer de niveau
        if len(self.asteroides) == 0:
            self.vaisseau.niveau += 1
            self.passer_au_niveau_superieur(1)#self.vaisseau.niveau)

        #faire apparaitre la Soucoupe et gerer sa courte vie
        if time.time() - self.debut_game > self.temps_avant_apparition_soucoupe[self.nb_apparition]:
            if self.soucoupe_la == False:
                self.soucoupe_test()
                self.soucoupe_la = True
                self.temps_la = time.time()
            self.S.tirer(self.vaisseau.xcor(),self.vaisseau.ycor())
            if time.time() - self.temps_la > 15:
                self.S.partir()
                self.soucoupe_la = False
                self.nb_apparition += 1


        #faire bouger les animations
        self.vaisseau.avancer()

        for missile in self.vaisseau.tirs:
            missile.avancer()
        for asteroide in self.asteroides:
            asteroide.avancer()


        #tenir compte des interactions entre
        #les animations
            if self.vaisseau.toucher(asteroide):
                self.vaisseau.devier(asteroide.heading(),
                                     asteroide.vitesse)
                self.vaisseau.nb_vies -= 1



            for tir in self.vaisseau.tirs:
                if tir.toucher(asteroide):

                    nom_os = sys.platform
                    if nom_os == 'Darwin':
                        os.system("afplay explosion.wav&")

                    elif nom_os == 'Linux':
                        os.system("aplay explosion.wav &")

                    elif nom_os == 'win32':
                        winsound.PlaySound("explosion.wav", winsound.SND_ASYNC)
                    asteroide.exploser(self.asteroides,self.vaisseau)
                    tir.goto(TROU_NOIR)
                    self.vaisseau.tirs.remove(tir)
                    self.nb_touche += 1
                elif tir.xcor() == TROU_NOIR[0]:
                    self.vaisseau.tirs.remove(tir)


        if self.soucoupe_la == True:

            for missile_S in self.S.tir_missile:
                missile_S.avancer2()

                if self.vaisseau.toucher(missile_S):
                    self.vaisseau.devier(missile_S.heading() + 90,
                                         missile_S.vitesse)
                    self.vaisseau.nb_vies -= 1
                    missile_S.goto(TROU_NOIR)
                    self.S.tir_missile.remove(missile_S)
                elif missile_S.xcor() == TROU_NOIR[0]:
                    self.S.tir_missile.remove(missile_S)



    def ecran_accueil(self):
        self.stylo.undo()
        msg = "BIENVENUE ! APPUYEZ SUR UP POUR JOUER"
        self.stylo.penup()
        self.stylo.goto(-300, 150)
        self.stylo.write(msg, font=("Calibri DejaVu Math TeX Gyre", 20, "normal"))

    def afficher(self,path):
        msg = "NIVEAU : {}  NB_VIES : {} SCORE: {}   ".format(self.vaisseau.niveau,
                                                              self.vaisseau.nb_vies,
                                                              self.vaisseau.score)
        self.stylo.undo()
        self.stylo.penup()
        self.stylo.goto(-360, 350)
        self.stylo.write(msg, font=("Arial", 16, "normal"))

    def aquisition_valeur(self,path):
        """
        Retourne un dictionnaire avec 'Score' la clé d'une liste des scores
                                      'Auteur' la clé d'une liste des auteurs des scores

        Paramètre:
        ----------
        path:
            str:le chemin pour accéder au fichier score.

                /!\ la syntaxe du fichier des scores doit être comme suit:
                |score|:|auteur|;

        Exemple d'utilisation:
        ----------------------
        >>d = aquisition_valeur("scores.txt")
        >>d['Auteur'][0]

            retourne le premier auteur du document scores.txt qui se trouve dan sle repertoire courant

        ####

        >>d= aquisition_valeur("scores.txt")
        >>d['Score'][1]

            retourne le deuxième score du document scores.txt qui se trouve dans le repertoire courant
        """
        f = open(path,'r')
        s = f.read()
        q,t = 0,0
        score_pred = {'Score':[],'Auteur':[]}
        for i in s:
            q += 1
            if len(s) == 0:
                return score_pred
            elif i==":":
                score_pred['Score'].append(s[t:q-1])
                t = q
            elif i == ";":
                score_pred['Auteur'].append(s[t:q-1])
                t = q + 1
        return score_pred

    def bilan_partie(self,path):
        if self.vaisseau.nb_tir != 0:
            precision = self.nb_touche / self.vaisseau.nb_tir
            print(str(round(precision * 100)) + "% DE PRECISION")
        else:
            precision = 0
        mon_score = self.vaisseau.score
        d_score = self.aquisition_valeur(path) #d_score veut dire: dictionnaire des scores
        msg = f"TON SCORE EST: {mon_score}"
        msg2 = f"LE MEILLEUR SCORE EST {d_score['Score'][0]} PAR {d_score['Auteur'][0]}"
        msg3 = f"{str(round(precision * 100))}% de précision"
        self.stylo.penup()
        self.stylo.goto(-150, 10)
        self.stylo.write(msg,
                         font=("Arial", 22, "normal"))
        self.stylo.penup()
        self.stylo.goto(-300, -20)
        self.stylo.write(msg2,
                         font=("Arial", 22, "normal"))

        self.stylo.penup()
        self.stylo.goto(-100, -50)
        self.stylo.write(msg3,
                         font=("Arial", 22, "normal"))
        # si le score du joueur est strictement supérieur
        # au plus petit des dix meilleurs scores, insérer le score et
        # le pseudo du joueur dans le fichier scores.txt à sa place

        k = 0
        #print(d_score)
        if mon_score >= int(d_score['Score'][len(d_score['Score'])-1]) and len(d_score['Score']) <= 10:
            nom = str(self.ecran.textinput("Asteroids", f"Ton score: {mon_score}.\nQuel est ton pseudo ?"))
            if len(d_score['Score']) == 0:
                d_score['Score'].append(self.vaisseau.score)
                d_score['Auteur'].append(nom)

            elif self.vaisseau.score > int(d_score['Score'][len(d_score['Score'])-1]):
                for score in d_score['Score']:
                    if int(score) <= self.vaisseau.score:
                        if len(d_score['Score']) == 10:
                            d_score['Score'].pop()
                            d_score['Auteur'].pop()
                            d_score['Score'].insert(k,self.vaisseau.score)
                            d_score['Auteur'].insert(k,nom)
                        else:
                            d_score['Score'].insert(k,self.vaisseau.score)
                            d_score['Auteur'].insert(k,nom)
                        break
                    k += 1
            else:
                d_score['Score'].append(self.vaisseau.score)
                d_score['Auteur'].append(nom)
        else:
            time.sleep(2)
        self.rentrer_score(d_score,path)

    def rentrer_score(self,dico,path):
        f = open(path,'w')
        k = 0
        for score in dico['Score']:
            f.write(str(score)  + ':' + dico['Auteur'][k] + ';\n')
            k += 1
        f.close()

    def boucle_principale(self,path):
        while True:
            #écran d'accueil
            nom_os = sys.platform
            if nom_os == 'Darwin':
                os.system("afplay ouverture.wav&")

            elif nom_os == 'Linux':
                os.system("aplay ouverture.wav &")

            elif nom_os == 'win32':
                winsound.PlaySound("ouverture.wav", winsound.SND_ASYNC)

            while not self.commencer_une_partie:
                self.ecran_accueil()
            #une partie en cours
            self.ecran.getcanvas().delete('all')
            self.commencer()
            self.debut_game = time.time()
            self.temps_avant_apparition_soucoupe = [(i*3)*60 for i in range(1,4)]
            self.temps_avant_apparition_soucoupe.insert(0,6)
            self.temps_avant_apparition_soucoupe.append(1000000)
            while self.partie_est_en_cours():
                turtle.update()
                self.jouer()
                self.afficher(path)
            #on efface les dessins des tortues
            nom_os = sys.platform
            if nom_os == 'Darwin':
                os.system("afplay mort.wav&")

            elif nom_os == 'Linux':
                os.system("aplay mort.wav &")

            elif nom_os == 'win32':
                winsound.PlaySound("mort.wav", winsound.SND_ASYNC)

            self.ecran.getcanvas().delete('all')
            #bilan de la partie
            self.bilan_partie(path)
            self.ecran.getcanvas().delete('all')
            #arrêt du jeu ou nouvelle partie pour un nouveau joueur
            msg = "Une nouvelle partie ?(O/N)"
            self.stylo.penup()
            self.stylo.goto(-150, 10)
            self.stylo.write(msg,
                             font=("Arial", 22, "normal"))
            choix = self.ecran.textinput("Asteroids", msg)
            if choix == 'N' or choix == 'n' or choix == "":
                break
            elif choix == 'O' or choix == 'o':
                #on retourne vers l'écran d'accueil pour une nouvelle
                #partie
                self.commencer_une_partie = False
                self.vaisseau.nb_vies = 3
                turtle.onkeypress(self.commencer, "Up")
                turtle.listen()
        #self.ecran.ondestroy()
#------------MAIN------------
if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose = False)
    jeu = Jeu()
    jeu.boucle_principale("scores.txt")
    turtle.bye()
